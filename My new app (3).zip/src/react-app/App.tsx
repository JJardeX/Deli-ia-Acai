import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import CardapioPage from "@/react-app/pages/Cardapio";
import MontarAcaiPage from "@/react-app/pages/MontarAcai";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/cardapio" element={<CardapioPage />} />
        <Route path="/montar" element={<MontarAcaiPage />} />
      </Routes>
    </Router>
  );
}
