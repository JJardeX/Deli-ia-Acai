import { MessageCircle } from "lucide-react";
import { Button } from "@/react-app/components/ui/button";

const WHATSAPP_NUMBER = "5598970228814";

export default function FloatingWhatsApp() {
  const handleClick = () => {
    const message = encodeURIComponent("Olá! Gostaria de fazer um pedido 🍇");
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank");
  };

  return (
    <Button
      onClick={handleClick}
      className="fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full bg-green-500 hover:bg-green-600 shadow-2xl shadow-green-500/50 hover:shadow-green-500/70 hover:scale-110 transition-all duration-300 flex items-center justify-center group"
      size="icon"
    >
      <MessageCircle className="w-8 h-8 text-white group-hover:scale-110 transition-transform" />
      <span className="sr-only">Contato WhatsApp</span>
    </Button>
  );
}
