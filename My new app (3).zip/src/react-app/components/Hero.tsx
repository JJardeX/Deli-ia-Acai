import { Button } from "@/react-app/components/ui/button";
import { Link } from "react-router";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[#1A0A2E] via-[#2D1B4E] to-[#5B2C6F] min-h-[90vh] flex items-center">
      {/* Animated wavy background pattern */}
      <div className="absolute inset-0 opacity-20">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="wave-pattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M0 50 Q 25 30, 50 50 T 100 50" fill="none" stroke="#FDE047" strokeWidth="2" className="opacity-60"/>
              <path d="M0 70 Q 25 50, 50 70 T 100 70" fill="none" stroke="#FDE047" strokeWidth="2" className="opacity-40"/>
              <path d="M0 30 Q 25 10, 50 30 T 100 30" fill="none" stroke="#A855F7" strokeWidth="1.5" className="opacity-30"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#wave-pattern)"/>
        </svg>
      </div>

      {/* Glowing orbs */}
      <div className="absolute top-1/4 right-20 w-96 h-96 bg-yellow-400/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 left-10 w-[500px] h-[500px] bg-purple-500/20 rounded-full blur-3xl"></div>
      <div className="absolute top-40 left-1/4 w-64 h-64 bg-pink-500/20 rounded-full blur-3xl"></div>

      {/* Content */}
      <div className="container mx-auto px-6 py-24 relative z-10">
        <div className="flex flex-col items-center text-center lg:items-start lg:text-left max-w-4xl">
          {/* Logo */}
          <div className="mb-8">
            <img 
              src="https://019c25cc-977c-771f-9e37-c844c6510843.mochausercontent.com/aeccce42-e3ea-4eb1-ac4b-4213f34f304c-Photoroom.png" 
              alt="Delícia Açaí Logo"
              className="w-64 md:w-80 lg:w-96 h-auto drop-shadow-2xl animate-in fade-in zoom-in duration-700"
            />
          </div>
          
          <p className="text-2xl md:text-3xl lg:text-4xl text-white mb-12 leading-relaxed font-bold drop-shadow-lg max-w-2xl">
            O verdadeiro sabor do açaí que conquista.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start w-full">
            <Button 
              asChild 
              size="lg"
              className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-purple-900 font-black text-lg px-10 py-7 rounded-full shadow-2xl shadow-yellow-500/40 hover:shadow-yellow-500/60 hover:scale-110 transition-all duration-300 border-2 border-yellow-600"
            >
              <Link to="/cardapio">🍽️ Ver Cardápio</Link>
            </Button>
            
            <Button 
              asChild 
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-black text-lg px-10 py-7 rounded-full shadow-2xl shadow-purple-600/40 hover:shadow-purple-600/60 transition-all duration-300 hover:scale-110 border-2 border-purple-500"
            >
              <Link to="/montar">🍧 Fazer Pedido</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom wave decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-b from-transparent to-white pointer-events-none"></div>
    </section>
  );
}
