import { Link, useLocation } from "react-router";
import { Menu, X } from "lucide-react";
import { Button } from "@/react-app/components/ui/button";
import { useState } from "react";

export default function Navbar() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const links = [
    { to: "/", label: "Home" },
    { to: "/cardapio", label: "Cardápio" },
    { to: "/montar", label: "Monte seu Açaí" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0D0518]/80 backdrop-blur-md border-b border-purple-400/10">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 hover:opacity-90 transition-opacity">
            <img 
              src="https://019c25cc-977c-771f-9e37-c844c6510843.mochausercontent.com/aeccce42-e3ea-4eb1-ac4b-4213f34f304c-Photoroom.png"
              alt="Delícia Açaí"
              className="h-12 w-auto"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`font-semibold transition-all duration-300 relative ${
                  location.pathname === link.to
                    ? "text-yellow"
                    : "text-purple-200 hover:text-white"
                }`}
              >
                {link.label}
                {location.pathname === link.to && (
                  <div className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full"></div>
                )}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white hover:bg-purple-600/20"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-purple-400/10">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setIsOpen(false)}
                className={`block py-3 font-semibold transition-colors duration-200 ${
                  location.pathname === link.to
                    ? "text-yellow"
                    : "text-purple-200 hover:text-white"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
