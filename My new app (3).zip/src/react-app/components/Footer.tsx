import { MapPin, Clock, MessageCircle } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-[#1A0A2E] via-[#2D1B4E] to-[#0D0518] text-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-yellow/10 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-6 py-16 relative z-10">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="mb-6">
              <img 
                src="https://019c25cc-977c-771f-9e37-c844c6510843.mochausercontent.com/aeccce42-e3ea-4eb1-ac4b-4213f34f304c-Photoroom.png"
                alt="Delícia Açaí"
                className="h-24 w-auto mb-4"
              />
            </div>
            <p className="text-purple-200 leading-relaxed font-semibold mb-4">
              Faça seu pedido e receba pelo delivery.
            </p>
            <div className="space-y-2">
              <a 
                href="https://instagram.com/_delicia_acai_00" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-yellow hover:text-yellow/80 transition-colors font-semibold flex items-center gap-2"
              >
                📷 Instagram: @_delicia_acai_00
              </a>
              <a 
                href="https://wa.me/5598970228814" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-yellow hover:text-yellow/80 transition-colors font-semibold flex items-center gap-2"
              >
                📱 WhatsApp: (98) 97022-8814
              </a>
            </div>
          </div>

          {/* Delivery Info */}
          <div>
            <h3 className="font-bold text-xl mb-6 text-yellow">Delivery</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3 group">
                <div className="w-10 h-10 rounded-full bg-purple-600/20 flex items-center justify-center group-hover:bg-purple-600/30 transition-colors">
                  <MapPin className="w-5 h-5 text-yellow" />
                </div>
                <div>
                  <p className="font-semibold text-white">Localização</p>
                  <p className="text-purple-300/70">São Luís - MA</p>
                </div>
              </div>
              <div className="flex items-start gap-3 group">
                <div className="w-10 h-10 rounded-full bg-purple-600/20 flex items-center justify-center group-hover:bg-purple-600/30 transition-colors">
                  <Clock className="w-5 h-5 text-yellow" />
                </div>
                <div>
                  <p className="font-semibold text-white">Horário</p>
                  <p className="text-purple-300/70">Segunda a Domingo</p>
                  <p className="text-purple-300/70">Consulte disponibilidade</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div>
            <h3 className="font-bold text-xl mb-6 text-yellow">Faça seu Pedido</h3>
            <a 
              href="https://wa.me/5598970228814?text=Olá!%20Gostaria%20de%20fazer%20um%20pedido%20🍇"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white font-bold px-6 py-4 rounded-full shadow-lg shadow-green-500/30 hover:shadow-green-500/50 transition-all duration-300 hover:scale-105"
            >
              <MessageCircle className="w-5 h-5" />
              Pedir pelo WhatsApp
            </a>
          </div>
        </div>

        <div className="border-t border-purple-400/10 mt-12 pt-8 text-center">
          <p className="text-purple-400/60 text-sm">
            &copy; 2024 Delícia Açaí. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
