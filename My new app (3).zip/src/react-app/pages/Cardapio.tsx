import Navbar from "@/react-app/components/Navbar";
import Footer from "@/react-app/components/Footer";
import FloatingWhatsApp from "@/react-app/components/FloatingWhatsApp";
import { Card } from "@/react-app/components/ui/card";
import { acaiSizes, frutas, complementos, caldas, cremes, ADICIONAL_PRECO } from "@/data/acai";

export default function CardapioPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-white via-purple-50 to-white">
      <Navbar />
      <div className="h-16"></div>
      
      <FloatingWhatsApp />

      {/* Hero */}
      <section className="py-12 sm:py-16 bg-gradient-to-br from-[#1A0A2E] via-[#2D1B4E] to-[#5B2C6F] relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 right-0 w-96 h-96 bg-yellow rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-400 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 text-center relative z-10">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white mb-4 sm:mb-6 drop-shadow-2xl">
            Nosso Cardápio
          </h1>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-purple-200 max-w-3xl mx-auto px-4">
            Conheça nossos tamanhos e ingredientes disponíveis
          </p>
        </div>
      </section>

      {/* Tamanhos */}
      <section className="py-12 sm:py-16 container mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-purple-900 mb-4">
            📏 Tamanhos Disponíveis
          </h2>
          <p className="text-base sm:text-lg text-slate-600">
            Escolha o tamanho ideal para sua fome
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto">
          {acaiSizes.map((size) => (
            <Card
              key={size.id}
              className="p-6 border-2 border-purple-200 hover:border-purple-400 hover:shadow-xl transition-all duration-300"
            >
              <div className="text-center mb-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full mb-4 shadow-lg shadow-purple-500/30">
                  <span className="text-3xl">🍇</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-purple-900 mb-2">{size.name}</h3>
                <div className="text-3xl sm:text-4xl font-black text-yellow mb-3">
                  R$ {size.price.toFixed(2)}
                </div>
              </div>
              
              {size.description && (
                <p className="text-sm text-purple-600 font-semibold mb-4 text-center bg-purple-50 py-2 px-3 rounded-lg">
                  {size.description}
                </p>
              )}
              
              <div className="space-y-2 text-slate-700">
                <p className="flex items-center gap-2">
                  <span className="text-xl">🍌</span>
                  <span className="font-semibold">{size.limits.frutas} fruta{size.limits.frutas > 1 ? 's' : ''}</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-xl">🍫</span>
                  <span className="font-semibold">{size.limits.complementos} complemento{size.limits.complementos > 1 ? 's' : ''}</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-xl">🍯</span>
                  <span className="font-semibold">{size.limits.caldas} calda{size.limits.caldas > 1 ? 's' : ''}</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-xl">🥛</span>
                  <span className="font-semibold">{size.limits.cremes} creme{size.limits.cremes > 1 ? 's' : ''}</span>
                </p>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Ingredientes */}
      <section className="py-12 sm:py-16 bg-gradient-to-b from-purple-50 to-white">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-purple-900 mb-4">
              🍓 Ingredientes Disponíveis
            </h2>
            <p className="text-base sm:text-lg text-slate-600">
              Monte seu açaí com os melhores ingredientes
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Frutas */}
            <Card className="p-6 sm:p-8 border-2 border-green-200 bg-green-50/50">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg shadow-green-500/30">
                  <span className="text-2xl">🍌</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-green-900">Frutas</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {frutas.map((fruta) => (
                  <span
                    key={fruta}
                    className="px-4 py-2 bg-green-500 text-white font-bold rounded-full text-sm shadow-md"
                  >
                    {fruta}
                  </span>
                ))}
              </div>
            </Card>

            {/* Complementos */}
            <Card className="p-6 sm:p-8 border-2 border-purple-200 bg-purple-50/50">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center shadow-lg shadow-purple-500/30">
                  <span className="text-2xl">🍫</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-purple-900">Complementos</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {complementos.map((comp) => (
                  <span
                    key={comp}
                    className="px-4 py-2 bg-purple-600 text-white font-bold rounded-full text-sm shadow-md"
                  >
                    {comp}
                  </span>
                ))}
              </div>
            </Card>

            {/* Caldas */}
            <Card className="p-6 sm:p-8 border-2 border-yellow-200 bg-yellow-50/50">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-yellow rounded-full flex items-center justify-center shadow-lg shadow-yellow/30">
                  <span className="text-2xl">🍯</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-yellow-900">Caldas</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {caldas.map((calda) => (
                  <span
                    key={calda}
                    className="px-4 py-2 bg-yellow text-purple-900 font-bold rounded-full text-sm shadow-md"
                  >
                    {calda}
                  </span>
                ))}
              </div>
            </Card>

            {/* Cremes */}
            <Card className="p-6 sm:p-8 border-2 border-purple-300 bg-purple-100/50">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-purple-700 rounded-full flex items-center justify-center shadow-lg shadow-purple-700/30">
                  <span className="text-2xl">🥛</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-purple-900">Cremes</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {cremes.map((creme) => (
                  <span
                    key={creme}
                    className="px-4 py-2 bg-purple-700 text-white font-bold rounded-full text-sm shadow-md"
                  >
                    {creme}
                  </span>
                ))}
              </div>
            </Card>
          </div>

          {/* Info Adicionais */}
          <Card className="mt-8 p-6 sm:p-8 bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300 max-w-3xl mx-auto">
            <h3 className="text-xl sm:text-2xl font-black text-purple-900 mb-4 text-center">
              ℹ️ Informações Importantes
            </h3>
            <div className="space-y-3 text-purple-900">
              <p className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Adicional de fruta: <span className="font-bold">R$ {ADICIONAL_PRECO.toFixed(2)}</span></span>
              </p>
              <p className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Adicional de complemento: <span className="font-bold">R$ {ADICIONAL_PRECO.toFixed(2)}</span></span>
              </p>
              <p className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Todos os tamanhos incluem açaí tradicional de primeira qualidade</span>
              </p>
              <p className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Entregas disponíveis em toda São Luís - MA</span>
              </p>
            </div>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}
