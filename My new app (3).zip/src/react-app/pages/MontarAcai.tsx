import { useState } from "react";
import Navbar from "@/react-app/components/Navbar";
import Footer from "@/react-app/components/Footer";
import FloatingWhatsApp from "@/react-app/components/FloatingWhatsApp";
import { Button } from "@/react-app/components/ui/button";
import { Card } from "@/react-app/components/ui/card";
import { Check, Plus, ShoppingCart } from "lucide-react";
import { acaiSizes, frutas, complementos, caldas, cremes, ADICIONAL_PRECO, type AcaiSize } from "@/data/acai";

const WHATSAPP_NUMBER = "5598970228814";

export default function MontarAcaiPage() {
  const [selectedSize, setSelectedSize] = useState<AcaiSize | null>(null);
  const [selectedFrutas, setSelectedFrutas] = useState<string[]>([]);
  const [selectedComplementos, setSelectedComplementos] = useState<string[]>([]);
  const [selectedCaldas, setSelectedCaldas] = useState<string[]>([]);
  const [selectedCremes, setSelectedCremes] = useState<string[]>([]);

  const toggleItem = (item: string, list: string[], setList: (list: string[]) => void, limit: number) => {
    if (list.includes(item)) {
      setList(list.filter(i => i !== item));
    } else if (list.length < limit) {
      setList([...list, item]);
    }
  };

  const calculateTotal = () => {
    if (!selectedSize) return 0;
    
    let total = selectedSize.price;
    
    // Adicionais de frutas
    const extraFrutas = Math.max(0, selectedFrutas.length - selectedSize.limits.frutas);
    total += extraFrutas * ADICIONAL_PRECO;
    
    // Adicionais de complementos
    const extraComplementos = Math.max(0, selectedComplementos.length - selectedSize.limits.complementos);
    total += extraComplementos * ADICIONAL_PRECO;
    
    return total;
  };

  const generateWhatsAppMessage = () => {
    if (!selectedSize) return "";

    let message = `🍇 *Pedido Delícia Açaí*\n\n`;
    message += `📏 Tamanho: ${selectedSize.name}\n`;
    message += `💰 Preço base: R$ ${selectedSize.price.toFixed(2)}\n\n`;
    
    if (selectedFrutas.length > 0) {
      message += `🍌 Frutas:\n`;
      selectedFrutas.forEach(fruta => message += `  • ${fruta}\n`);
      message += `\n`;
    }
    
    if (selectedComplementos.length > 0) {
      message += `🍫 Complementos:\n`;
      selectedComplementos.forEach(comp => message += `  • ${comp}\n`);
      message += `\n`;
    }
    
    if (selectedCaldas.length > 0) {
      message += `🍯 Caldas:\n`;
      selectedCaldas.forEach(calda => message += `  • ${calda}\n`);
      message += `\n`;
    }
    
    if (selectedCremes.length > 0) {
      message += `🥛 Cremes:\n`;
      selectedCremes.forEach(creme => message += `  • ${creme}\n`);
      message += `\n`;
    }

    const total = calculateTotal();
    message += `💵 *Total: R$ ${total.toFixed(2)}*`;
    
    return message;
  };

  const handleFinalizarPedido = () => {
    const message = encodeURIComponent(generateWhatsAppMessage());
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank");
  };

  const canFinalize = selectedSize && 
    selectedFrutas.length > 0 && 
    selectedCaldas.length > 0 && 
    selectedCremes.length > 0;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-white via-purple-50 to-white">
      <Navbar />
      <div className="h-16"></div>
      
      <FloatingWhatsApp />

      {/* Hero */}
      <section className="py-12 sm:py-16 bg-gradient-to-br from-[#1A0A2E] via-[#2D1B4E] to-[#5B2C6F] relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-yellow rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-purple-400 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 text-center relative z-10">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-4 sm:mb-6 drop-shadow-2xl">
            Monte o seu Açaí
          </h1>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-purple-200 max-w-3xl mx-auto px-4">
            Escolha o tamanho, frutas e complementos do seu jeito.
          </p>
        </div>
      </section>

      {/* Etapas */}
      <section className="py-8 sm:py-12 lg:py-16 container mx-auto px-4 sm:px-6 pb-32">
        {/* Tamanhos */}
        <div className="mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl font-black text-purple-900 mb-2 sm:mb-3 text-center">📏 Escolha o Tamanho</h2>
          <p className="text-center text-slate-600 mb-6 sm:mb-8 px-4">Selecione o tamanho ideal para você</p>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {acaiSizes.map((size) => (
              <Card
                key={size.id}
                onClick={() => setSelectedSize(size)}
                className={`p-6 cursor-pointer transition-all duration-300 hover:shadow-2xl hover:scale-105 border-2 ${
                  selectedSize?.id === size.id
                    ? "border-purple-600 bg-purple-50 shadow-xl shadow-purple-500/30"
                    : "border-purple-200 hover:border-purple-400"
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-2xl font-bold text-purple-900">{size.name}</h3>
                  {selectedSize?.id === size.id && (
                    <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                      <Check className="w-5 h-5 text-white" />
                    </div>
                  )}
                </div>
                
                {size.description && (
                  <p className="text-sm text-purple-600 mb-3 font-semibold">{size.description}</p>
                )}
                
                <div className="space-y-2 mb-4 text-sm text-slate-600">
                  <p>🍌 {size.limits.frutas} fruta{size.limits.frutas > 1 ? 's' : ''}</p>
                  <p>🍫 {size.limits.complementos} complemento{size.limits.complementos > 1 ? 's' : ''}</p>
                  <p>🍯 {size.limits.caldas} calda{size.limits.caldas > 1 ? 's' : ''}</p>
                  <p>🥛 {size.limits.cremes} creme{size.limits.cremes > 1 ? 's' : ''}</p>
                </div>
                
                <div className="text-3xl font-black text-purple-900">
                  R$ {size.price.toFixed(2)}
                </div>
              </Card>
            ))}
          </div>
        </div>

        {selectedSize && (
          <>
            {/* Frutas */}
            <div className="mb-12 sm:mb-16">
              <h2 className="text-3xl sm:text-4xl font-black text-purple-900 mb-2 sm:mb-3 text-center">🍌 Frutas</h2>
              <p className="text-center text-slate-600 mb-2">
                Escolha até {selectedSize.limits.frutas} fruta{selectedSize.limits.frutas > 1 ? 's' : ''} 
                ({selectedFrutas.length} selecionada{selectedFrutas.length !== 1 ? 's' : ''})
              </p>
              {selectedFrutas.length > selectedSize.limits.frutas && (
                <p className="text-center text-sm text-purple-600 font-semibold mb-6">
                  +{selectedFrutas.length - selectedSize.limits.frutas} adicional (R$ {((selectedFrutas.length - selectedSize.limits.frutas) * ADICIONAL_PRECO).toFixed(2)})
                </p>
              )}
              
              <div className="flex flex-wrap gap-3 justify-center max-w-4xl mx-auto">
                {frutas.map((fruta) => (
                  <Button
                    key={fruta}
                    onClick={() => toggleItem(fruta, selectedFrutas, setSelectedFrutas, 10)}
                    variant={selectedFrutas.includes(fruta) ? "default" : "outline"}
                    className={`px-6 py-6 rounded-full font-bold text-base transition-all duration-300 ${
                      selectedFrutas.includes(fruta)
                        ? "bg-green-500 hover:bg-green-600 text-white shadow-lg shadow-green-500/30"
                        : "border-2 border-green-500 text-green-700 hover:bg-green-50"
                    }`}
                  >
                    {fruta}
                    {selectedFrutas.includes(fruta) && <Check className="ml-2 w-4 h-4" />}
                  </Button>
                ))}
              </div>
            </div>

            {/* Complementos */}
            <div className="mb-12 sm:mb-16">
              <h2 className="text-3xl sm:text-4xl font-black text-purple-900 mb-2 sm:mb-3 text-center">🍫 Complementos</h2>
              <p className="text-center text-slate-600 mb-2">
                Escolha até {selectedSize.limits.complementos} complemento{selectedSize.limits.complementos > 1 ? 's' : ''} 
                ({selectedComplementos.length} selecionado{selectedComplementos.length !== 1 ? 's' : ''})
              </p>
              {selectedComplementos.length > selectedSize.limits.complementos && (
                <p className="text-center text-sm text-purple-600 font-semibold mb-6">
                  +{selectedComplementos.length - selectedSize.limits.complementos} adicional (R$ {((selectedComplementos.length - selectedSize.limits.complementos) * ADICIONAL_PRECO).toFixed(2)})
                </p>
              )}
              
              <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-5xl mx-auto">
                {complementos.map((comp) => (
                  <Button
                    key={comp}
                    onClick={() => toggleItem(comp, selectedComplementos, setSelectedComplementos, 10)}
                    variant={selectedComplementos.includes(comp) ? "default" : "outline"}
                    className={`px-5 py-6 rounded-xl font-bold text-sm transition-all duration-300 ${
                      selectedComplementos.includes(comp)
                        ? "bg-purple-600 hover:bg-purple-700 text-white shadow-lg shadow-purple-500/30"
                        : "border-2 border-purple-400 text-purple-700 hover:bg-purple-50"
                    }`}
                  >
                    {comp}
                    {selectedComplementos.includes(comp) && <Check className="ml-2 w-4 h-4" />}
                  </Button>
                ))}
              </div>
            </div>

            {/* Caldas */}
            <div className="mb-12 sm:mb-16">
              <h2 className="text-3xl sm:text-4xl font-black text-purple-900 mb-2 sm:mb-3 text-center">🍯 Caldas</h2>
              <p className="text-center text-slate-600 mb-6">
                Escolha até {selectedSize.limits.caldas} calda{selectedSize.limits.caldas > 1 ? 's' : ''} 
                ({selectedCaldas.length} selecionada{selectedCaldas.length !== 1 ? 's' : ''})
              </p>
              
              <div className="flex flex-wrap gap-3 justify-center max-w-3xl mx-auto">
                {caldas.map((calda) => (
                  <Button
                    key={calda}
                    onClick={() => toggleItem(calda, selectedCaldas, setSelectedCaldas, selectedSize.limits.caldas)}
                    variant={selectedCaldas.includes(calda) ? "default" : "outline"}
                    disabled={!selectedCaldas.includes(calda) && selectedCaldas.length >= selectedSize.limits.caldas}
                    className={`px-6 py-6 rounded-full font-bold text-base transition-all duration-300 ${
                      selectedCaldas.includes(calda)
                        ? "bg-yellow hover:bg-yellow/90 text-purple-900 shadow-lg shadow-yellow/30"
                        : "border-2 border-yellow text-yellow-700 hover:bg-yellow/10"
                    }`}
                  >
                    {calda}
                    {selectedCaldas.includes(calda) && <Check className="ml-2 w-4 h-4" />}
                  </Button>
                ))}
              </div>
            </div>

            {/* Cremes */}
            <div className="mb-12 sm:mb-16">
              <h2 className="text-3xl sm:text-4xl font-black text-purple-900 mb-2 sm:mb-3 text-center">🥛 Cremes</h2>
              <p className="text-center text-slate-600 mb-6">
                Escolha até {selectedSize.limits.cremes} creme{selectedSize.limits.cremes > 1 ? 's' : ''} 
                ({selectedCremes.length} selecionado{selectedCremes.length !== 1 ? 's' : ''})
              </p>
              
              <div className="flex flex-wrap gap-3 justify-center max-w-2xl mx-auto">
                {cremes.map((creme) => (
                  <Button
                    key={creme}
                    onClick={() => toggleItem(creme, selectedCremes, setSelectedCremes, selectedSize.limits.cremes)}
                    variant={selectedCremes.includes(creme) ? "default" : "outline"}
                    disabled={!selectedCremes.includes(creme) && selectedCremes.length >= selectedSize.limits.cremes}
                    className={`px-6 py-6 rounded-full font-bold text-base transition-all duration-300 ${
                      selectedCremes.includes(creme)
                        ? "bg-purple-600 hover:bg-purple-700 text-white shadow-lg shadow-purple-500/30"
                        : "border-2 border-purple-400 text-purple-700 hover:bg-purple-50"
                    }`}
                  >
                    {creme}
                    {selectedCremes.includes(creme) && <Check className="ml-2 w-4 h-4" />}
                  </Button>
                ))}
              </div>
            </div>

            {/* Info adicionais */}
            <Card className="p-6 bg-yellow/10 border-2 border-yellow/50 max-w-2xl mx-auto mb-12">
              <h3 className="font-bold text-xl text-purple-900 mb-3 flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Adicionais
              </h3>
              <div className="space-y-2 text-purple-800">
                <p>• Adicional de fruta: <span className="font-bold">R$ 2,00</span></p>
                <p>• Adicional de complemento: <span className="font-bold">R$ 2,00</span></p>
              </div>
            </Card>

            {/* Resumo e Finalizar */}
            <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-purple-900 via-purple-800 to-purple-900 shadow-2xl border-t-4 border-yellow z-40 safe-area-bottom">
              <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">
                  <div className="text-white text-center sm:text-left">
                    <p className="text-xs sm:text-sm text-purple-200 mb-1">Total do Pedido</p>
                    <p className="text-2xl sm:text-3xl md:text-4xl font-black">R$ {calculateTotal().toFixed(2)}</p>
                  </div>
                  
                  <Button
                    onClick={handleFinalizarPedido}
                    disabled={!canFinalize}
                    size="lg"
                    className="w-full sm:w-auto bg-green-500 hover:bg-green-600 text-white font-black text-base sm:text-lg px-6 sm:px-10 py-5 sm:py-7 rounded-full shadow-2xl shadow-green-500/50 hover:shadow-green-500/70 hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:hover:scale-100"
                  >
                    <ShoppingCart className="mr-2 w-5 h-5 sm:w-6 sm:h-6" />
                    <span className="hidden sm:inline">Finalizar Pedido no WhatsApp</span>
                    <span className="sm:hidden">Pedir no WhatsApp</span>
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}
      </section>

      <Footer />
    </div>
  );
}
