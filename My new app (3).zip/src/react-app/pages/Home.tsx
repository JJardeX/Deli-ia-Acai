import Navbar from "@/react-app/components/Navbar";
import Hero from "@/react-app/components/Hero";
import Footer from "@/react-app/components/Footer";
import FloatingWhatsApp from "@/react-app/components/FloatingWhatsApp";
import { Sparkles, Leaf, Heart } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      
      {/* Spacer for fixed navbar */}
      <div className="h-16"></div>
      
      <FloatingWhatsApp />
      
      <Hero />
      
      {/* Features Section */}
      <section className="py-24 bg-gradient-to-b from-white via-purple-50 to-white relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute top-0 left-0 w-full h-full opacity-30">
          <div className="absolute top-20 right-10 w-72 h-72 bg-purple-100/50 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-yellow-50 rounded-full blur-3xl"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-black bg-gradient-to-r from-purple-900 via-purple-700 to-purple-900 bg-clip-text text-transparent mb-4">
              Por que escolher o Delícia Açaí?
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Frescor, energia, sabor e praticidade
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="group bg-white rounded-3xl p-10 shadow-xl border border-purple-100 hover:shadow-2xl hover:scale-105 transition-all duration-300 hover:border-purple-300">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-purple-500/30">
                <Sparkles className="w-10 h-10 text-purple-600" />
              </div>
              <h3 className="text-3xl font-bold text-purple-900 mb-4">Açaí Premium</h3>
              <p className="text-slate-600 leading-relaxed text-lg">
                Trabalhamos apenas com açaí de primeira qualidade, cremoso e saboroso, 
                direto dos melhores fornecedores.
              </p>
            </div>

            <div className="group bg-white rounded-3xl p-10 shadow-xl border border-purple-100 hover:shadow-2xl hover:scale-105 transition-all duration-300 hover:border-purple-300">
              <div className="w-20 h-20 bg-gradient-to-br from-green-100 to-green-200 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-green-400/20">
                <Leaf className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-3xl font-bold text-purple-900 mb-4">Ingredientes Frescos</h3>
              <p className="text-slate-600 leading-relaxed text-lg">
                Todas as frutas e complementos são selecionados diariamente para garantir 
                máximo frescor e sabor.
              </p>
            </div>

            <div className="group bg-white rounded-3xl p-10 shadow-xl border border-purple-100 hover:shadow-2xl hover:scale-105 transition-all duration-300 hover:border-purple-300">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-purple-500/30">
                <Heart className="w-10 h-10 text-purple-600" />
              </div>
              <h3 className="text-3xl font-bold text-purple-900 mb-4">Feito com Amor</h3>
              <p className="text-slate-600 leading-relaxed text-lg">
                Cada açaí é preparado com carinho e dedicação, pensando em proporcionar 
                a melhor experiência para você.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
