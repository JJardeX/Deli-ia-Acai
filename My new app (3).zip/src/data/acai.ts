export interface AcaiSize {
  id: string;
  name: string;
  ml: string;
  price: number;
  limits: {
    frutas: number;
    complementos: number;
    caldas: number;
    cremes: number;
  };
  description?: string;
}

export const acaiSizes: AcaiSize[] = [
  {
    id: "250ml",
    name: "250ml",
    ml: "250ml",
    price: 10.00,
    limits: { frutas: 1, complementos: 1, caldas: 1, cremes: 1 }
  },
  {
    id: "330ml",
    name: "330ml",
    ml: "330ml",
    price: 13.00,
    limits: { frutas: 1, complementos: 2, caldas: 1, cremes: 1 }
  },
  {
    id: "400ml",
    name: "400ml",
    ml: "400ml",
    price: 16.00,
    limits: { frutas: 2, complementos: 3, caldas: 2, cremes: 1 }
  },
  {
    id: "500ml",
    name: "500ml",
    ml: "500ml",
    price: 20.00,
    limits: { frutas: 3, complementos: 3, caldas: 2, cremes: 1 }
  },
  {
    id: "700ml",
    name: "700ml",
    ml: "700ml",
    price: 25.00,
    limits: { frutas: 4, complementos: 4, caldas: 2, cremes: 1 }
  },
  {
    id: "300ml-garrafa",
    name: "300ml (garrafa)",
    ml: "300ml",
    price: 14.00,
    limits: { frutas: 1, complementos: 1, caldas: 1, cremes: 1 },
    description: "Banana + leite em pó"
  }
];

export const frutas = [
  "Banana",
  "Morango",
  "Uva",
  "Abacaxi",
  "Maçã"
];

export const complementos = [
  "Leite em pó",
  "Paçoca",
  "Granola",
  "Amendoim",
  "Gotas de chocolate",
  "M&Ms",
  "Cerealball",
  "Jujuba",
  "Sucrilhos"
];

export const caldas = [
  "Leite condensado",
  "Calda de chocolate",
  "Calda de morango",
  "Calda de maracujá"
];

export const cremes = [
  "Creme de Ninho",
  "Creme de Oreo"
];

export const ADICIONAL_PRECO = 2.00;
